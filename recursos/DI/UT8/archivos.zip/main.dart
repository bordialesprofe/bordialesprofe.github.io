import 'package:flutter/material.dart';

void main() {
  runApp(const MainApp());
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: HomePage(),
    );
  }
}
/// Clase Heroe
/// Representa el modelo de datos de un heroe del Salon de Heroes.
/// Agrupa toda la informacion necesaria para mostrar una tarjeta en la interfaz.
class Heroe {
  /// Ruta de la imagen del heroe
  final String imagePath;

  /// Nombre del heroe
  final String nombre;

  /// Clase o rol del heroe (guerrero, mago, explorador, etc.)
  final String clase;

  /// Descripcion del heroe que se muestra al interactuar con la tarjeta
  final String descripcion;

  /// Constructor constante.
  /// Permite crear objetos Heroe con todos sus datos definidos desde el inicio.
  const Heroe({
    required this.imagePath,
    required this.nombre,
    required this.clase,
    required this.descripcion,
  });
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  // -----------------------------
  // DATOS (lista de objetos)
  // -----------------------------
  final List<Heroe> heroes = const [
    Heroe(
      imagePath: 'assets/images/enano_pixel_128.png',
      nombre: 'Borin',
      clase: 'Guerrero',
      descripcion: 'Un guerrero enano experto en combate cuerpo a cuerpo.',
    ),
    Heroe(
      imagePath: 'assets/images/explorador_pixel_128.png',
      nombre: 'Marek',
      clase: 'Explorador',
      descripcion: 'Rastreador agil, conoce caminos y trampas del bosque.',
    ),
    Heroe(
      imagePath: 'assets/images/exploradora_pixel_128.png',
      nombre: 'Selene',
      clase: 'Exploradora',
      descripcion: 'Exploradora sigilosa, especialista en reconocimiento.',
    ),
    Heroe(
      imagePath: 'assets/images/guerrero_pixel_128.png',
      nombre: 'Theron',
      clase: 'Guerrero',
      descripcion: 'Caballero disciplinado, defiende al grupo en batalla.',
    ),
    Heroe(
      imagePath: 'assets/images/guerrera_pixel_128.png',
      nombre: 'Ronan',
      clase: 'Guerrera',
      descripcion: 'Guerrera valiente, siempre al frente del combate.',
    ),
    Heroe(
      imagePath: 'assets/images/hechicero_pixel_128.png',
      nombre: 'Arden',
      clase: 'Mago',
      descripcion: 'Mago de fuego, domina hechizos ofensivos.',
    ),
    Heroe(
      imagePath: 'assets/images/hechicera_pixel_128.png',
      nombre: 'Liora',
      clase: 'Maga',
      descripcion: 'Maga arcana, combina magia y estrategia.',
    ),
  ];

  // Estado: héroe seleccionado
  String heroeSeleccionado = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Salón de héroes - UT8',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        centerTitle: true,
        backgroundColor: const Color(0xC1035B02),
        foregroundColor: const Color(0xC1FFFFFF),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            tooltip: 'Limpiar selección',
            onPressed: () {
              setState(() {
                heroeSeleccionado = '';
              });
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: ListView(
          children: [
            for (final heroe in heroes) ...[
                // `...[ ]` expande la lista generada por el `for` dentro de `children`.
                // Asi se pueden insertar varios widgets por heroe.
                // Aqui se anaden: heroCard(...) y SizedBox(...).
              heroCard(
                context: context,
                imagePath: heroe.imagePath,
                nombre: heroe.nombre,
                clase: heroe.clase,
                descripcion: heroe.descripcion,
                seleccionado: heroeSeleccionado == heroe.nombre,
              ),
              const SizedBox(height: 12),
            ],
          ],
        ),
      ),
    );
  }

 Widget heroCard({
    required BuildContext context,
    required String imagePath,
    required String nombre,
    required String clase,
    required String descripcion,
    required bool seleccionado,
  }) {
    return InkWell(
      onTap: () {
        setState(() {
          heroeSeleccionado = nombre;
        });
        //snackBar
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(descripcion)),
        );       
      },
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: seleccionado ? const Color(0xFFDFF2DF) : Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: const Color(0xC1035B02),
            width: seleccionado ? 4 : 2,
          ),
        ),
        child: Row(
          children: [
            Image.asset(imagePath, width: 64, height: 64),
            const SizedBox(width: 12),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  nombre,
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Text(
                  clase,
                  style: const TextStyle(fontSize: 14, color: Colors.grey),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

