// UT8 - Tablon del Centro
// Este archivo ira creciendo a medida que avancemos en DOM + eventos.

console.log("app.js cargado correctamente");